# Diesel rolling coal

A Pen created on CodePen.io. Original URL: [https://codepen.io/Austinhudspath/pen/GRzgzyG](https://codepen.io/Austinhudspath/pen/GRzgzyG).

